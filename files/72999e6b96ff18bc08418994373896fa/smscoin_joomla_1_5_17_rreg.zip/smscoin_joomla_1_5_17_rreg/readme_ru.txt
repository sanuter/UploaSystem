 Данный модуль предоставляет возможность платной регистрации пользователей на вашем сайте,
посредством отправки платной смс под Joomla 1.5.14.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Вся информация, предоставленная в рамках данного программного продукта,
является интеллектуальной собственностью компании Agregator ltd, Israel.

Данный программный продукт предназначен для участников партнерской программы
сайта http://smscoin.com/ при использовании услуги СМС:КЛЮЧ. Использование
программного продукта или его части вне означенной партнерской программы
является нарушением прав компании и преследуется в соответствии с действующим
законодательством.

Компания Agregator ltd. Israel не несет никакой ответственности
за функционирование данного программного обеспечения,
а также за потерю прибыли, в том числе упущенную выгоду, и/или убытки,
связанные с использованием данного программного обеспечения.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


 К стандартной форме регистрации, добавляется инструкция для отправки
платного смс. Отправив смс согласно инструкции, пользователь получит
ответное смс с паролем. Заполнив личные данные и введя пароль,
пользователь сможет завершить регистрацию.

На сайте smscoin.com в настройках услуги смс:ключ вы можете установить
как время жизни генерируемого пароля, так и/или кол-во активаций.

 Имеет смысл установить значения:

 Время действия: 0
 Количество запросов: 0

 Не смотря на то, что это безлимитный пароль, пользователь сможет его использовать только
для одной регистрации.

 Для использования данного плагина требуется регистрация на сайте SmsCoin.com
и подключение услуги смс:ключ.

 Регистрация и подключение услуги смс:ключ - абсолютно бесплатны.

 Для получения статистики установите компонент smscoin_joomla_1_5_9_manager


 Установка:

	Установка делится на 2 этапа: установка плагина и установка пача

	1. Установка плагина:
	Expansion manager-> Install-> Загрузить файл пакета
	Укжите имя zip файла smscoin_joomla_1_5_14_rreg.zip

	2.Конфигурация плагина:
	Expansion manager->Plugins manager->SmsCoin registration->Параметры плагина

	Заполните поля:
	*Введите ID смс:ключа - находтся в контрольной панели в разделе смс:ключ на сайте smscoin.com
	*Введите секретный код - любой набор символов, но такой же как в настрйках смс:ключа
	*Введите секретный код - выберите нужный язык.
	*Время задачи не меняйте - если установить в 0 то при первом же открытии страницы тарифная сетка
	обновится. Тарифная сетка обновляется автоматически каждый час.

 	3. Выставьте права на запись (766) файлу http://ваш сайт.ru/plugins/content/smscoin_rreg/lib/local.js

	4. На сайте smscoin.com в настройках смс ключа поставьте галочку на "Передача паролей", укажите
		путь к файлу http://example.ru/plugins/content/smscoin_rreg/result.php и пароль (Secret Code)
		такой же как и в настройках плагина.

	5. Установка пача:

		5.1 Вы можете просто скопировать файлы с папки patch в соответствующие директории.

		или

		5.1 Откройте файл /components/com_user/controller.php найдите строки

			if ($useractivation == '1')
			{
				jimport('joomla.user.helper');
				$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
				$user->set('block', '1');
			}

			и скопируйте после них

			#smscoin
			require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
			$smsrreg = new CSmscoin_rreg();
			if($smsrreg->sms_check_password() != 1) {
				JError::raiseWarning('', JText::_( "Wrong sms password!" ));
				$this->setRedirect('index.php?option=com_user&view=register');
				return;
			}
			#smscoin

			в этомже файле найдите строку

			UserController::_sendMail($user, $password);

			и скопируйте после нее

			#smscoin
			$plugin			=& JPluginHelper::getPlugin('content', 'smscoin_rreg');
			$pluginParams	= new JParameter( $plugin->params );
			$key_id = $pluginParams->get('key_id');
			$db = &JFactory::getDBO();
			$db->setQuery("UPDATE #__skeys SET k_status=0 WHERE k_pair='".addslashes($_POST['s_pair'])."'
									AND k_key='".intval($key_id)."'");
			$db->query();
			#smscoin

		5.2 Откройте файл /components/com_user/views/register/tmpl/default.php найдите строки

			<tr>
				<td colspan="2" height="40">
					<?php echo JText::_( 'REGISTER_REQUIRED' ); ?>
				</td>
			</tr>

			и скопируйте ПЕРЕД ними

			<tr>
				<td colspan="2" height="40">
					<?php
						require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
						$smscont = new CSmscoin_rreg();
						echo $smscont->sms_form();
					?>
				</td>
			</tr>

 Установка завершина.



 Удаление:

	1. Удалите плагин.

	2. Откройте файл /components/com_user/controller.php и удалите строки


		#smscoin
		require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
		$smsrreg = new CSmscoin_rreg();
		if($smsrreg->sms_check_password() != 1) {
			JError::raiseWarning('', JText::_( "Wrong sms password!" ));
			$this->setRedirect('index.php?option=com_user&view=register');
			return;
		}
		#smscoin

		а также строки

		#smscoin
		$plugin			=& JPluginHelper::getPlugin('content', 'smscoin_rreg');
		$pluginParams	= new JParameter( $plugin->params );
		$key_id = $pluginParams->get('key_id');
		$db = &JFactory::getDBO();
		$db->setQuery("UPDATE #__skeys SET k_status=0 WHERE k_pair='".addslashes($_POST['s_pair'])."'
								AND k_key='".intval($key_id)."'");
		$db->query();
		#smscoin

	3 Откройте файл /components/com_user/views/register/tmpl/default.php и удалите строки

		<tr>
			<td colspan="2" height="40">
				<?php
					require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
					$smscont = new CSmscoin_rreg();
					echo $smscont->sms_form();
				?>
			</td>
		</tr>

 Плагин удален.






Версия 0.2 Июль 2010
