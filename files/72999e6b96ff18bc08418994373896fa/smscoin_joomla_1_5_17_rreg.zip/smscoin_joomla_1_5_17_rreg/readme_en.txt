SmsCoin  - sms:key module paif registration for Joomla 1.5.14.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=
All information within this software product is the
intellectual property of Agregator ltd, Israel.

Given software can be used by http://smscoin.com/ clients
for sms:key service only. Any other use of the software 
is violation of the company's right and will be pursued
according to operating law.

Agregator ltd. Israel will not be held liable for any loss
or damage of any kind as a result of using this software,
including any lost revenues and/or data.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


Description:

	The following module enables paid registration for users on your website,
	via SMS-message.
	 
	To standard registration form an instruction for sending SMS is added in
	addition to a field for entering the received password in reply message.
	 
	Module settings stored in Admin Panel, at the time of module configuration 
        sms:key ID must be specified, secret password (the same as in sms:key settings
        on smscoin.net website), language for instruction display.
	
	 
	On smscoin.net in sms:key service settings you can set the time of
	a generated password as well as the number of times it can activated. 
	 
	You should set the following values:
 
	Time limit: 0 
	The number of requests: 0 

	Even though the password is unlimited, user can use it for one registration only.
 
	To use this plug-in you have to be registered on smscoin.net
         http://smscoin.net/account/register/ , approve your e-mail account
         and connect to sms:key service.

	


Installation:

	Installation process is divided into two phases: plugin and patch settings

	1. Plugin setup:
	
		1.1 Install plugin smscoin_joomla_1_5_14_rreg.zip in your website admin panel.

	2. Go to your website admin panel->Plugin Manager->SmsCoin registration and setup the plugin specifying
		*Enter sms:key ID - stored in control panel under sms:key section on smscoin.com website
		*Enter secret code - any set of characters but the same as in sms:key settings
		*Enter secret code - choose preferable language.
		*Do not change cron time - if set to 0 then the first time the page is open, the rate scale is updated.
			Rate scale is updated automatically each hour.

	3. On smscoin.net in sms:key settings check mark "Passwords transfer", specify
		file path to http://example.com/plugins/content/smscoin_rreg/result.php and password (Secret Code)
		the same as n plugin settings.

	4. Patch setup:

		4.1 Simply copy the files from patch folder to relevant directories.

		or

		4.1 Open /components/com_user/controller.php file find lines

			if ($useractivation == '1')
			{
				jimport('joomla.user.helper');
				$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
				$user->set('block', '1');
			}

			and copy afterwards

			#smscoin
			require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
			$smsrreg = new CSmscoin_rreg();
			if($smsrreg->sms_check_password() != 1) {
				JError::raiseWarning('', JText::_( "Wrong sms password!" ));
				$this->setRedirect('index.php?option=com_user&view=register');
				return;
			}
			#smscoin

			in the same file find line

			UserController::_sendMail($user, $password);

			and copy afterwards

			#smscoin
			$plugin			=& JPluginHelper::getPlugin('content', 'smscoin_rreg');
			$pluginParams	= new JParameter( $plugin->params );
			$key_id = $pluginParams->get('key_id');
			$db = &JFactory::getDBO();
			$db->setQuery("UPDATE #__skeys SET k_status=0 WHERE k_pair='".addslashes($_POST['s_pair'])."'
									AND k_key='".intval($key_id)."'");
			$db->query();	
			#smscoin

		4.2 Open /components/com_user/views/register/tmpl/default.php file find lines

			<tr>
				<td colspan="2" height="40">
					<?php echo JText::_( 'REGISTER_REQUIRED' ); ?>
				</td>
			</tr>

			and copy BEFORE the line

			<tr>
				<td colspan="2" height="40">
					<?php
						require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
						$smscont = new CSmscoin_rreg();
						echo $smscont->sms_form();
					?>
				</td>
			</tr>			

	Installation process is finished.



Uninstall:

	1. Uninstall plugin.

	2. Open /components/com_user/controller.php file and delete lines


		#smscoin
		require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
		$smsrreg = new CSmscoin_rreg();
		if($smsrreg->sms_check_password() != 1) {
			JError::raiseWarning('', JText::_( "Wrong sms password!" ));
			$this->setRedirect('index.php?option=com_user&view=register');
			return;
		}
		#smscoin

	        and the following lines

		#smscoin
		$plugin			=& JPluginHelper::getPlugin('content', 'smscoin_rreg');
		$pluginParams	= new JParameter( $plugin->params );
		$key_id = $pluginParams->get('key_id');
		$db = &JFactory::getDBO();
		$db->setQuery("UPDATE #__skeys SET k_status=0 WHERE k_pair='".addslashes($_POST['s_pair'])."'
								AND k_key='".intval($key_id)."'");
		$db->query();	
		#smscoin

	3 Open /components/com_user/views/register/tmpl/default.php file and delete lines

		<tr>
			<td colspan="2" height="40">
				<?php
					require_once(JPATH_BASE.DS."plugins/content/smscoin_rreg.php");
					$smscont = new CSmscoin_rreg();
					echo $smscont->sms_form();
				?>
			</td>
		</tr>			

	Plugin uninstalled.


Support
-------------
For further questions, please contact SmsCoin technical support 
via support@smscoin.com

